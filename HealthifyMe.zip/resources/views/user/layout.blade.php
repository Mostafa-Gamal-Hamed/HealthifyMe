@include("user.inc.header")
@include("user.inc.navbar")

@yield('body')

@include("user.inc.footer")
