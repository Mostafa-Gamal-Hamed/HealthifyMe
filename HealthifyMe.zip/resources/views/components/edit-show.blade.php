<a href="{{ $url }}" class="btn btn-md btn-{{ $class }}" title="{{ $title }}">
    {!! $text !!}
</a>