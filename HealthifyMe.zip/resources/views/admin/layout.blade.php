@include("admin.inc.header")
@include("admin.inc.sidebar")
@include("admin.inc.navbar")

@yield('body')

@include("admin.inc.footer")