
<?php if(session()->get('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <h6 class="text-center"><i class="fas fa-check"></i> <?php echo e(session()->get('success')); ?></h6>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/success.blade.php ENDPATH**/ ?>