<?php
    $messages      = App\Models\Contact::where('status', 'unread')->count();
    $unread        = App\Models\Contact::where('status', 'unread')->latest()->take(5)->get();
    $notiCount     = App\Models\AskForDiet::count();
    $notifications = App\Models\AskForDiet::latest()->take(5)->get();
?>

<div class="content">
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand navbar-light sticky-top px-4 py-0" style="background-color: #191C24;">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <form class="d-none d-md-flex ms-4">
            <input class="form-control border-0" type="search" placeholder="Search">
        </form>
        <div class="navbar-nav align-items-center ms-auto">
            
            <div class="nav-item dropdown">
                <a href="#" class="nav-link" data-bs-toggle="dropdown">
                    <i class="fa fa-envelope me-lg-2 text-light"></i>
                    <span class="d-none d-lg-inline-flex text-light">
                        Message
                    </span>
                    <span class="fw-bold text-warning"><?php echo e($messages ? $messages : ''); ?></span>
                    </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <?php $__currentLoopData = $unread; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('admin.contact.show', $message->id)); ?>" class="dropdown-item mb-2">
                            <div class="d-flex align-items-center">
                                <img class="rounded-circle" src="<?php echo e(asset("images/users/avatar.png")); ?>" alt="" style="width: 40px; height: 40px;">
                                <div class="ms-2">
                                    <h6 class="fw-normal mb-0"><?php echo e($message->name); ?> send you a message</h6>
                                    <small><?php echo e($message->created_at->diffForHumans()); ?></small>
                                </div>
                            </div>
                        </a>
                        <hr class="dropdown-divider">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.contact.contacts')); ?>" class="nav-link text-dark text-center">See all message</a>
                </div>
            </div>
            
            <div class="nav-item dropdown">
                <a href="#" class="nav-link" data-bs-toggle="dropdown">
                    <i class="fa fa-bell me-lg-2 text-light"></i>
                    <span class="d-none d-lg-inline-flex text-light">Notifications</span>
                    <span class="fw-bold text-warning"><?php echo e($notiCount ? $notiCount : ''); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('admin.user.show', $notification->user->id)); ?>" class="dropdown-item">
                            <h6 class="fw-normal mb-0"><?php echo e($notification->user->firstName); ?></h6>
                            <span class="fw-normal mb-0 badge bg-<?php echo e($notification->ask === 'ask' ? 'primary' : 'warning text-dark'); ?>">
                                <?php echo e(ucfirst($notification->ask)); ?> <?php echo e($notification->ask === 'ask' ? 'activation' : 'diet'); ?>

                            </span><br>
                            <small><?php echo e($notification->created_at->diffForHumans()); ?></small>
                        </a>
                        <hr class="dropdown-divider">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('admin.dietRequests.diets')); ?>" class="dropdown-item text-center">See all notifications</a>
                </div>
            </div>
            
            <div class="nav-item dropdown">
                <a href="#" class="nav-link" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="<?php echo e(asset("images/users/avatar.png")); ?>" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex text-light"><?php echo e(Auth::user()->firstName); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end border-0 rounded-0 rounded-bottom m-0" style="background-color: #191C24;">
                    <a href="<?php echo e(route('dashboard')); ?>" class="dropdown-item accountNav">My Dashboard</a>
                    <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item accountNav">My Profile</a>
                    <form action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item accountNav">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->
<!-- Content Start -->
<div class="container position-relative bg-white p-3 m-0 mb-5"><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/inc/navbar.blade.php ENDPATH**/ ?>