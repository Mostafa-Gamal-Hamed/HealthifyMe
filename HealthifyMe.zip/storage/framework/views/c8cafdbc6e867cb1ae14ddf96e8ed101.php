
<?php if(session()->get("success")): ?>
    <div class="alert alert-success text-center">
        <h5><i class="fas fa-check"></i> <?php echo e(session()->get("success")); ?></h5>
    </div>
<?php endif; ?>


<?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger text-center">
            <h5><i class="fas fa-times"></i> <?php echo e($error); ?></h5>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/message.blade.php ENDPATH**/ ?>