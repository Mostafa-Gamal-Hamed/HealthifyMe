<?php $__env->startSection('title'); ?>
    <?php echo e($dietRequest->user->firstName); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid mb-5">
        <h2 class="text-center text-success fw-bold mt-3 mb-3"><?php echo e($dietRequest->user->firstName); ?> <?php echo e($dietRequest->user->lastName); ?></h2>

        <div class="shadow shadow-lg bg-light text-dark p-3 mb-5">
            sss
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/user/dietRequest/show.blade.php ENDPATH**/ ?>