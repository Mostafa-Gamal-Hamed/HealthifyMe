<?php $__env->startSection('title'); ?>
    <?php echo e($message->subject); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid mb-5">
        <h2 class="text-center text-success fw-bold mt-3 mb-3"><?php echo e($message->email); ?></h2>

        
        <?php echo $__env->make('message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="shadow shadow-xl text-dark p-3 mb-5" style="background-color: #eeeeee;">
            <div class="text-center overflow-auto">
                <h2 class="text-center">Contact message</h2>
                
                <div class="mb-3">
                    <p>User name</p>
                    <h4 class="w-50 m-auto p-2 rounded" style="background-color: white;">
                        <?php echo e($message->contact->name); ?>

                    </h4>
                </div>
                
                <div class="mb-3">
                    <p>User subject</p>
                    <h4 class="w-50 m-auto p-2 rounded" style="background-color: white;">
                        <?php echo e($message->contact->subject); ?>

                    </h4>
                </div>
                
                <div class="mb-3">
                    <p>User message</p>
                    <h4 class="w-50 m-auto p-2 rounded" style="background-color: white;">
                        <?php echo e($message->contact->message); ?>

                    </h4>
                </div>
            </div>
        </div>

        
        <div class="shadow shadow-xl text-dark p-3 mb-5" style="background-color: #eeeeee;">
            <div class="text-center overflow-auto">
                <h2 class="text-center text-primary">Replay message</h2>
                
                <div class="mb-3">
                    <p>Sender Name</p>
                    <h4 class="w-50 m-auto p-2 rounded" style="background-color: white;">
                        <?php echo e($message->user->firstName); ?> <?php echo e($message->user->lastName); ?>

                    </h4>
                </div>
                
                <div class="mb-3">
                    <p>To</p>
                    <h4 class="w-auto m-auto p-2 rounded" style="background-color: white;"><?php echo e($message->email); ?></h4>
                </div>
                
                <div class="mb-3">
                    <p>Message</p>
                    <h4 class="p-2 rounded" style="background-color:white;"><?php echo e($message->message); ?></h4>
                </div>
                <hr>

                <form action="<?php echo e(route('admin.sentMessage.secondDelete', $message->id)); ?>" class="text-center"
                    method="POST" class="col">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-md px-5" onclick="return confirm('Are you sure?');"
                        title="Delete message">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/contact/sent/show.blade.php ENDPATH**/ ?>