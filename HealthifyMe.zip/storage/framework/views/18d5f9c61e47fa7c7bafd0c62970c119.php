<?php $__env->startSection('title'); ?>
    <?php echo e($user->firstName); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid mb-5">
        <h2 class="text-center mt-5"><?php echo e($user->firstName . ' ' . $user->lastName); ?></h2>

        
        <div class="shadow shadow-lg bg-light text-dark p-3">
            
            <?php if($user->status === "active"): ?>
                <div class="text-end">
                    <a href="<?php echo e(route('admin.user.status', ['type' => 'inactive', 'id' => $user->id])); ?>"
                        class="btn btn-sm btn-danger" onclick="return confirm('Change to inactive?');">
                        Inactive Account
                    </a>
                </div>
            <?php endif; ?>

            
            <h3 class="text-center text-info fw-bold">Details</h3>
            <div class="row justify-content-center">
                <div class="col">
                    <h5 class="border border-2">Email: <?php echo e($user->email); ?></h5>
                    <h5>Age: <?php echo e($dietInfo ? $dietInfo->age : 0); ?> years</h5>
                    <h5 class="border border-2">Gender: <?php echo e($dietInfo ? $dietInfo->gender : 0); ?>

                    </h5>
                    <h5>Weight: <?php echo e($dietInfo ? $dietInfo->weight : 0); ?> kg</h5>
                </div>
                <div class="col">
                    <h5 class="border border-2">Height: <?php echo e($dietInfo ? $dietInfo->height : 0); ?> cm
                    </h5>
                    <h5>Activity level: <?php echo e($dietInfo ? $dietInfo->activity_level : 0); ?></h5>
                    <h5 class="border border-2">Workout hours per week:
                        <?php echo e($dietInfo ? $dietInfo->workout_hours_per_week : 0); ?> hour
                    </h5>
                    <h5>Created At: <?php echo e($dietInfo ? $dietInfo->created_at : 0); ?></h5>
                </div>
            </div>
            <hr>

            
            <h3 class="text-center fw-bold">Calories counting</h3>
            <div>
                <p class="text-muted text-center">BMR equation</p>
                <div id="equation">
                    <?php if($bmr): ?>
                        <h5 id="bmr">
                            BMR = (10 * <?php echo e($dietInfo->weight); ?>) + (6.25 * <?php echo e($dietInfo->height); ?>) - (5 *
                            <?php echo e($dietInfo->age); ?>) + 5 =
                            <?php echo e($bmr); ?> calories
                        </h5>
                    <?php else: ?>
                        <p class="text-muted">Some data is not completed.</p>
                    <?php endif; ?>
                </div>
                <p class="text-muted text-center">Calculating calories based on activity level</p>
                <div id="equationByActivity">
                    <h5>Total daily calories (TDEE): <?php echo e($tdee); ?> Calories</h5>
                </div>
                <div>
                    <h5>To lose 0.5 kg per week: <?php echo e($lose_05kg); ?> Calories per day</h5>
                    <h5>To lose 1 kg per week: <?php echo e($lose_1kg); ?> Calories per day</h5>
                    <h5>To lose 1.5 kg per week: <?php echo e($lose_1_5kg); ?> Calories per day</h5>
                </div>
            </div>
            <hr>

            
            <h3 class="text-center fw-bold mt-3">Special Diet</h3>
            <?php if(!$user->specialDiet): ?>
                <p class="text-danger">No special diet yet.</p>
            <?php else: ?>
                <div class="owl-carousel p-3 d-block rounded text-light" style="background-color: #0a58ca;">
                    <div class="owl-stage-outer">
                        <div class="owl-stage">
                            <div class="owl-item">
                                <h5>Name</h5>
                                <p><?php echo e($user->specialDiet->name); ?></p>
                                <h5>Description</h5>
                                <p class="p-2"><?php echo e($user->specialDiet->description); ?></p>
                                <h5>Calories</h5>
                                <p><?php echo e($user->specialDiet->calories); ?></p>
                                <h5>Workouts</h5>
                                <p class="p-2"><?php echo e($user->specialDiet->workouts); ?></p>
                                <h5>Created_at</h5>
                                <p><?php echo e($user->specialDiet->created_at->format('d-m-y')); ?></p>
                                <form action="<?php echo e(route('admin.specialDiet.delete', $user->specialDiet->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("DELETE"); ?>
                                    <button type="submit" class="btn btn-sm btn-warning">Remove</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <hr>

            
            <h3 class="text-center fw-bold mt-3">Diet</h3>
            <?php if($user->diets->isEmpty()): ?>
                <p class="text-danger">No diet yet.</p>
            <?php else: ?>
                <h5>Diets:<?php echo e(count($user->diets)); ?></h5>
                <div class="owl-carousel p-3 d-block rounded text-light" style="background-color: #197c87;">
                    <div class="owl-stage-outer">
                        <div class="owl-stage">
                            <?php $__currentLoopData = $user->diets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="owl-item">
                                    <p><?php echo e($loop->iteration); ?></p>
                                    <h5>Name</h5>
                                    <p><?php echo e($diet->name); ?></p>
                                    <h5>Description</h5>
                                    <p class="p-2"><?php echo e($diet->description); ?></p>
                                    <h5>Calories</h5>
                                    <p><?php echo e($diet->calories); ?></p>
                                    <h5>Workouts</h5>
                                    <p class="p-2"><?php echo e($diet->workouts); ?></p>
                                    <h5>Created_at</h5>
                                    <p><?php echo e($diet->created_at->format('d-m-Y')); ?></p>
                                    <form action="<?php echo e(route('admin.user.deleteDiet', $diet->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field("DELETE"); ?>
                                        <button type="submit" class="btn btn-sm btn-warning">Remove</button>
                                    </form>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <hr>

        
        <div class="shadow shadow-lg bg-light text-dark p-3 mb-5">
            <div class="d-flex flex-column justify-content-center">
                <?php if($user->status === 'active'): ?>
                    
                    <div class="col">
                        <h3 class="text-center text-success fw-bold mb-3">Choose diet</h3>
                        <form action="<?php echo e(route('admin.user.diet', $user->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="selectDiet" class="form-label">Diets</label>
                                <select class="form-select form-select-md <?php $__errorArgs = ['diet_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="diet_id" id="selectDiet">
                                    <option hidden>Select Diet</option>
                                    <?php $__currentLoopData = $diets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($diet->id); ?>"><?php echo e($diet->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['diet_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="btn btn-md btn-primary px-4">Create</button>
                        </form>
                    </div>
                    <hr>

                    
                    <div class="col">
                        <h3 class="text-center text-success fw-bold mb-3">Create special diet</h3>
                        <form action="<?php echo e(route('admin.specialDiet.store', "$user->id")); ?>" method="post"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <div class="form-floating mb-3">
                                <input type="text" name="name"
                                    class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                                    value="<?php echo e(old('name')); ?>" placeholder="Diet name:">
                                <label for="name">Diet name</label>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="form-floating mb-3">
                                <textarea name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Diet description:" id="description" style="height: 100px"><?php echo e(old('description')); ?></textarea>
                                <label for="description">Diet description</label>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="form-floating mb-3">
                                <input type="number" name="calories"
                                    class="form-control <?php $__errorArgs = ['calories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('calories')); ?>" id="calories" placeholder="Calories:">
                                <label for="calories">Calories</label>
                                <?php $__errorArgs = ['calories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="form-floating mb-3">
                                <textarea name="workouts" class="form-control <?php $__errorArgs = ['workouts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Workouts"
                                    id="workouts" style="height: 100px"><?php echo e(old('workouts')); ?></textarea>
                                <label for="workouts">Workouts</label>
                                <?php $__errorArgs = ['workouts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="mb-3">
                                <label for="images">Images</label>
                                <input type="file" name="images[]"
                                    class="form-control <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('images')); ?>" id="images" multiple
                                    accept=".jpg, .jpeg, .png, .gif">
                                <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <button type="submit" class="btn btn-md px-4 btn-primary">Create</button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="text-center">
                        <h5 class="text-danger fw-bold mb-3">The account has not been activated yet.</h5>
                        <a href="<?php echo e(route('admin.user.status', ['type' => 'active', 'id' => $user->id])); ?>"
                            class="btn btn-success" onclick="return confirm('Change to active?');">
                            Active Account
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            // Owl latestNews
            $('.owl-carousel').owlCarousel({
                items: 1,
                loop: true,
                center: true,
                margin: 10,
                dots: true,
                responsiveClass: true,
                autoHeight: true
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/user/show.blade.php ENDPATH**/ ?>