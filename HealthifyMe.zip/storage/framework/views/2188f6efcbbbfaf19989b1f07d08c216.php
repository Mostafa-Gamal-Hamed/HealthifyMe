<?php $__env->startSection('title'); ?>
    <?php echo e($recipe->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid mb-5">
        <h2 class="text-center text-success fw-bold mt-3 mb-3"><?php echo e($recipe->title); ?></h2>

        <div class="shadow shadow-lg bg-light text-dark p-3 mb-5">
            
            <div class="row gap-2">
                <picture class="col">
                    <?php if($recipe->images): ?>
                        <?php $__currentLoopData = json_decode($recipe->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset("storage/$image")); ?>" class="img-fluid rounded mb-2"
                                style="max-height:500px;" alt="Recipe">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/recipes/recipe.png')); ?>"
                            class="img-fluid rounded" style="max-height:500px;" alt="Recipe">
                    <?php endif; ?>
                </picture>
                <video class="col" style="max-height:500px;" controls>
                    <source
                        src="<?php echo e($recipe->video ? asset("storage/$recipe->video") : asset('images/recipes/video.png')); ?>"
                        type="video/mp4">
                </video>
            </div>
            <hr>

            
            <div class="mt-3">
                <div>
                    <h5 class="fw-bold">Description:</h5>
                    <p><?php echo $recipe->description; ?></p>
                </div>
                <h5 class="fw-bold">calories: <span><?php echo e($recipe->calories); ?>.</span></h5>
                <h5 class="fw-bold">Liked: <span class="text-primary"><?php echo e($likes); ?></span></h5>
                <h5 class="fw-bold">DisLiked: <span class="text-danger"><?php echo e($disLikes); ?></span></h5>
                <div class="d-flex align-items-center justify-content-between">
                    <span class="text-muted">By: <a href="<?php echo e(route('admin.user.show',$recipe->user->id)); ?>">
                        <?php echo e($recipe->user->firstName); ?> <?php echo e($recipe->user->lastName); ?>

                    </a></span>
                    <span class="text-muted">Created at: <?php echo e($recipe->created_at->format('d/m/Y')); ?></span>
                </div>
                <hr>
                <div class="d-flex">
                    <div class="col">
                        <?php if (isset($component)) { $__componentOriginalc77d73ad08c25a406445baf856031498 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc77d73ad08c25a406445baf856031498 = $attributes; } ?>
<?php $component = App\View\Components\EditShow::resolve(['url' => ''.e(route('admin.recipe.edit', $recipe->id)).'','class' => 'success w-75','title' => 'Edit','text' => '<i class=\'fa-solid fa-edit\'></i>'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('EditShow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\EditShow::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc77d73ad08c25a406445baf856031498)): ?>
<?php $attributes = $__attributesOriginalc77d73ad08c25a406445baf856031498; ?>
<?php unset($__attributesOriginalc77d73ad08c25a406445baf856031498); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc77d73ad08c25a406445baf856031498)): ?>
<?php $component = $__componentOriginalc77d73ad08c25a406445baf856031498; ?>
<?php unset($__componentOriginalc77d73ad08c25a406445baf856031498); ?>
<?php endif; ?>
                    </div>
                    <form action="<?php echo e(route('admin.recipe.secondDelete', $recipe->id)); ?>" method="POST" class="col">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-md w-75" onclick="return confirm('Are you sure?');"
                            title="Delete">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/recipe/show.blade.php ENDPATH**/ ?>