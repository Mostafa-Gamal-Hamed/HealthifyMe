<?php $__env->startSection('title'); ?>
    Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="p-3">
        <div class="shadow shadow-lg bg-light rounded h-100 p-4">
            <?php if($users->isEmpty()): ?>
                <h3 class="mb-5 text-center text-danger">No users found.</h3>
            <?php else: ?>
                <div class="row justify-content-between align-items-center mb-4">
                    <h6 class="col">Users</h6>
                    <form class="col" role="search">
                        <input class="form-control me-2" type="text" id="search" placeholder="Search by email or name"
                            aria-label="Search">
                    </form>
                </div>
                <div class="table-responsive">
                    <?php echo e($users->appends(request()->input())->links()); ?>

                    <table class="table text-center" id="showTable">
                        <thead>
                            <tr>
                                <th scope="col">ID.</th>
                                <th scope="col">First Name</th>
                                <th scope="col">Last Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Status</th>
                                <th scope="col">Joined at</th>
                                <th scope="col">email verified</th>
                                <th scope="col" colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($user->id); ?></td>
                                    <td><?php echo e($user->firstName); ?></td>
                                    <td><?php echo e($user->lastName); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <?php if($user->status == 'active'): ?>
                                        <td>
                                            <a href="<?php echo e(route('admin.user.status', ['type' => 'inactive', 'id' => $user->id])); ?>"
                                                class="nav-item badge bg-success"
                                                onclick="return confirm('Change to inactive?');">
                                                <?php echo e($user->status); ?>

                                            </a>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <a href="<?php echo e(route('admin.user.status', ['type' => 'active', 'id' => $user->id])); ?>"
                                                class="nav-item badge bg-danger"
                                                onclick="return confirm('Change to active?');">
                                                <?php echo e($user->status); ?>

                                            </a>
                                        </td>
                                    <?php endif; ?>
                                    <td><?php echo e($user->created_at->format('d-m-Y')); ?></td>
                                    <td><?php echo e($user->email_verified_at ? $user->email_verified_at->format('d-m-Y') : 'Not verified'); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.user.show', $user->id)); ?>" class="btn btn-md btn-success">
                                            <i class="fa-solid fa-info"></i></i>
                                        </a>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.user.delete', $user->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-md"
                                                onclick="return confirm('Are you sure?');">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $("#search").on("input", function() {
                var value = $(this).val().toLowerCase();
                $('#showTable').find('thead').hide();
                $('#showTable').find('tbody').hide();

                if (value === '') {
                    $('#showTable').find('thead').show();
                    $('#showTable').find('tbody').show();
                    return;
                }

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(route('admin.user.search', '')); ?>/" + value,
                    success: function(response) {
                        var resultHtml = '';

                        if (response.users && response.users.length > 0) {
                            var body = $('#showTable').find('tbody');
                            body.empty();

                            response.users.forEach(function(user) {
                                var created_at = new Date(user.created_at);
                                var createdAt = created_at.toLocaleDateString('en-GB');

                                var emailVerified = new Date(user.email_verified_at);
                                var verified = emailVerified.toLocaleDateString(
                                'en-GB');

                                if (user.status === 'active') {
                                    var status = `<a href="<?php echo e(route('admin.user.status', ['type' => 'inactive', 'id' => '__userId__'])); ?>"
                                        class='badge bg-success' onclick="return confirm('Change to inactive?');">
                                        ${user.status}
                                    </a>`;
                                    status = status.replace('__userId__', user.id);
                                } else {
                                    var status = `<a href="<?php echo e(route('admin.user.status', ['type' => 'active', 'id' => '__userId__'])); ?>"
                                        class='badge bg-danger' onclick="return confirm('Change to active?');">
                                        ${user.status}
                                    </a>`;
                                    status = status.replace('__userId__', user.id);
                                }

                                var show   = `<?php echo e(route('admin.user.show', '')); ?>/${user.id}`;
                                var remove = `<?php echo e(route('admin.user.delete', '')); ?>/${user.id}`;

                                body.append(`
                                    <tr>
                                        <td scope="row">${user.id}</td>
                                        <td>${user.firstName}</td>
                                        <td>${user.lastName}</td>
                                        <td>${user.email}</td>
                                        <td>${status}</td>
                                        <td>${createdAt}</td>
                                        <td>${verified || 'Not Verified'}</td>
                                        <td>
                                            <a href="${show}" class="btn btn-md btn-success">
                                                <i class="fa-solid fa-info"></i></i>
                                            </a>
                                        </td>
                                        <td>
                                            <form action="${remove}" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-md"
                                                    onclick="return confirm('Are you sure?');">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                `);
                            });

                        } else {
                            $('#showTable tbody').html(
                                `<tr><td colspan="8" class='text-danger fw-bold'>No results found.</td></tr>`
                            );
                        }

                        $('#showTable').find('thead').show();
                        $('#showTable').find('tbody').show();
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/user/index.blade.php ENDPATH**/ ?>