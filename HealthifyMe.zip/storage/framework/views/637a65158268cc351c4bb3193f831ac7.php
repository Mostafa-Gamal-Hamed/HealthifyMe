<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Admin , admin" name="keywords">
    <meta content="Admin pages" name="description">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">

    <!-- Icon  -->
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">

    <!-- Css -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('style'); ?>

    
    <link href="<?php echo e(asset('admin/css/Featherlight.css')); ?>" rel="stylesheet">

    
    <script src="<?php echo e(asset('js/jQuery.js')); ?>"></script>
    <?php echo $__env->yieldContent('jquery'); ?>
</head>

<body><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/inc/header.blade.php ENDPATH**/ ?>