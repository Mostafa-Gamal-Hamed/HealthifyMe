<?php $__env->startSection('title'); ?>
    <?php echo e($blog->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container mb-5">
        <div class="titlepage mt-2">
            <div class="p-2 border m-auto" style="max-width: 90%;height: 90%;">
                <img src="<?php echo e($blog->image ? asset("images/$blog->image") : asset('images/modern_logo.png')); ?>"
                    alt="<?php echo e($blog->image); ?>">
            </div>
            <h2 class="text-center mt-3"><?php echo e($blog->title); ?></h2>
        </div>

        
        <div class="p-3 shadow bg-light shadow-lg">
            <h4><?php echo e($blog->desc); ?></h4>
            <div class="d-flex justify-content-end align-items-center gap-3 mt-3">
                <button type="button" class="btn btn-outline-primary border px-5" id="like"
                    data-id="<?php echo e($blog->id); ?>" data-user="<?php echo e(Auth::id() ?? 0); ?>">
                    <i class="fa-solid fa-thumbs-up"></i> <span
                        id="likes-count-<?php echo e($blog->id); ?>"><?php echo e($blog->likes_count); ?></span>
                </button>

                <button type="button" class="btn btn-outline-danger border px-5" id="disLike"
                    data-id="<?php echo e($blog->id); ?>" data-user="<?php echo e(Auth::id() ?? 0); ?>">
                    <i class="fa-solid fa-thumbs-down"></i> <span
                        id="disLike-count-<?php echo e($blog->id); ?>"><?php echo e($blog->disLikes_count); ?></span>
                </button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $("#like").on('click', function(e) {
                e.preventDefault();

                const button = $(this);
                const id     = button.data('id');
                const user   = button.data('user');
                const url    = "<?php echo e(route('blog.like', '')); ?>/" + id;
                const data   = {
                    _token: '<?php echo e(csrf_token()); ?>',
                    user: user
                };

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: data,
                    success: function(response) {
                        if (response.location) {
                            window.location.href = "<?php echo e(route('login')); ?>";
                        }
                        $('#likes-count-' + id).text(response.likes_count);
                        $('#disLike-count-' + id).text(response.disLikes_count);
                    },
                    error: function(xhr, status, error) {
                        console.error(`Error occurred: ${error}`);
                    }
                });
            });

            $("#disLike").on('click', function(e) {
                e.preventDefault();

                const button = $(this);
                const id     = button.data('id');
                const user   = button.data('user');
                const url    = "<?php echo e(route('blog.disLike', '')); ?>/" + id;
                const data   = {
                    _token: '<?php echo e(csrf_token()); ?>',
                    user: user
                };

                $.ajax({
                    url: url,
                    type: 'POST',
                    data: data,
                    success: function(response) {
                        if (response.location) {
                            window.location.href = "<?php echo e(route('login')); ?>";
                        }
                        $('#likes-count-' + id).text(response.likes_count);
                        $('#disLike-count-' + id).text(response.disLikes_count);
                    },
                    error: function(xhr, status, error) {
                        console.error(`Error occurred: ${error}`);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/user/blog/show.blade.php ENDPATH**/ ?>