<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jquery'); ?>
    <script src="<?php echo e(asset('admin/js/chart.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <!-- Spinner Start -->
    
    <!-- Spinner End -->
    <div class="mt-4">
        <h2 class="mb-4 fw-bold">Dashboard</h2>
        
        <div class="row gap-2 align-items-center justify-content-around">
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Users</h5>
                    <h3 class="text-danger"><?php echo e($users ? $users : 0); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Diets</h5>
                    <h3 class="text-primary"><?php echo e($diets ? $diets : 0); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Special diets</h5>
                    <h3 class="text-purple"><?php echo e($special ? $special : 0); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Blogs</h5>
                    <h3 class="text-info"><?php echo e($blogs ? $blogs : 0); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Request diets</h5>
                    <h3 class="text-danger"><?php echo e($askDiet ? $askDiet : 0); ?></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 text-center">
                    <h5>Request a diet change</h5>
                    <h3 class="text-success"><?php echo e($changeDiet ? $changeDiet : 0); ?></h3>
                </div>
            </div>
        </div>

        
        <div class="row mt-4">
            <div class="col-md-8">
                <div class="card p-3">
                    <h5>Business Overview</h5>
                    <canvas id="businessChart"></canvas>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-3 mb-3">
                    <h5>Ask for diets</h5>
                    <h3 class="text-danger">14,000</h3>
                    <p>42% higher than last month</p>
                </div>
                <div class="card p-3">
                    <h5>Active Installations</h5>
                    <h3 class="text-success">34,000</h3>
                    <p>19% less than last month</p>
                </div>
            </div>
        </div>

        
        <div class="card p-3 mt-4">
            <div class="d-flex justify-content-between">
                <h5>Contact messages</h5>
                <a href="<?php echo e(route('admin.contact.contacts')); ?>">See all</a>
            </div>
            <?php if($messages->isNotEmpty()): ?>
                <div class="table-responsive">
                    <table class="table table-hover text-center">
                        <thead class="table-dark">
                            <tr>
                                <th>No.</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Status</th>
                                <th>Received</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($message->name); ?></td>
                                    <td><?php echo e($message->email); ?></td>
                                    <td><?php echo e($message->subject); ?></td>
                                    <?php if($message->status == 'unread'): ?>
                                        <td><span class="badge bg-warning text-dark"><?php echo e($message->status); ?></span></td>
                                    <?php else: ?>
                                        <td><span class="badge bg-secondary"><?php echo e($message->status); ?></span></td>
                                    <?php endif; ?>
                                    <td><?php echo e($message->created_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('admin.message.show', $message->id)); ?>"
                                            class="btn btn-sm btn-primary">
                                            View
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
            <div class="text-center">
                <h5 class="text-danger">No messages found.</h5>
            </div>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        var ctx = document.getElementById('businessChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Return',
                    data: [65, 59, 80, 81, 56, 55],
                    backgroundColor: 'red'
                }, {
                    label: 'Revenue',
                    data: [28, 48, 40, 19, 86, 27],
                    backgroundColor: 'blue'
                }, {
                    label: 'Cost',
                    data: [18, 28, 30, 50, 76, 47],
                    backgroundColor: 'purple'
                }]
            },
            options: {
                responsive: true
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/home.blade.php ENDPATH**/ ?>