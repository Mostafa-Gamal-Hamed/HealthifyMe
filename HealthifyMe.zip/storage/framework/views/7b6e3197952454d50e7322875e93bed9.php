<?php $__env->startSection('title'); ?>
    Diets
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="p-3">
        <h2 class="text-center mb-3 text-success fw-bold">All Diets</h2>
        <div class="shadow shadow-lg bg-light rounded h-100 mb-5">
            <?php if($diets->isEmpty()): ?>
                <h3 class="mb-5 text-center text-danger">No diets found.</h3>
            <?php else: ?>
                
                <form class="d-flex justify-content-end mb-3 p-2" role="search">
                    <input class="form-control w-50" type="text" id="search" placeholder="Search by name or calories"
                        aria-label="Search">
                </form>

                
                <div class="table-responsive">
                    <?php echo e($diets->appends(request()->input())->links()); ?>

                    <table class="table text-center" id="showTable">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Description</th>
                                <th scope="col">Calories</th>
                                <th scope="col">User</th>
                                <th scope="col">Created</th>
                                <th scope="col" colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $diets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($diet->id); ?></td>
                                    <td><?php echo e($diet->name); ?></td>
                                    <td>
                                        <span data-featherlight="<p><?php echo e($diet->description); ?></p>" style="cursor: pointer;">
                                            <?php echo e(Str::limit($diet->description, 50, '....')); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($diet->calories); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.user.show', "$diet->user_id")); ?>" class="nav-link">
                                            <?php echo e($diet->user->firstName); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($diet->created_at->format('d-m-Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.specialDiet.edit', $diet->id)); ?>"
                                            class="btn btn-md btn-success">
                                            <i class="fa-solid fa-edit"></i></i>
                                        </a>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.specialDiet.delete', $diet->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-md"
                                                onclick="return confirm('Are you sure?');">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php if($diets->isNotEmpty()): ?>
        <script>
            $(document).ready(function() {
                $("#search").on("input", function() {
                    var value = $(this).val().toLowerCase();
                    $('#showTable').find('thead').hide();
                    $('#showTable').find('tbody').hide();

                    if (value === '') {
                        $('#showTable').find('thead').show();
                        $('#showTable').find('tbody').show();
                        return;
                    }

                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(route('admin.specialDiet.search', '')); ?>/" + value,
                        success: function(response) {
                            console.log(response.diets);

                            if (response.diets && response.diets.length > 0) {
                                var body = $('#showTable').find('tbody');
                                body.empty();

                                response.diets.forEach(function(diet) {
                                    var created_at = new Date(diet.created_at);
                                    var createdAt  = created_at.toLocaleDateString('en-GB');

                                    var data = `data-featherlight='<p>${diet.description}</p>'`;
                                    var description = `
                                        <span ${data} style="cursor: pointer;">
                                            ${diet.description.length > 50 ? diet.description.substring(0, 50) + '....' : diet.description}
                                        </span>
                                    `;

                                    var userName = `
                                        <a href="<?php echo e(route('admin.user.show', "$diet->user_id")); ?>" class="nav-link">
                                            <?php echo e($diet->user->firstName); ?>

                                        </a>
                                    `;

                                    body.append(`
                                        <tr>
                                            <td scope="row">${diet.id}</td>
                                            <td>${diet.name}</td>
                                            <td>${description}</td>
                                            <td>${diet.calories}</td>
                                            <td>${userName}</td>
                                            <td>${createdAt}</td>
                                            <td>
                                                <a href="<?php echo e(route('admin.specialDiet.edit', $diet->id)); ?>" class="btn btn-md btn-success">
                                                    <i class="fa-solid fa-edit"></i></i>
                                                </a>
                                            </td>
                                            <td>
                                                <form action="<?php echo e(route('admin.specialDiet.delete', $diet->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-md"
                                                        onclick="return confirm('Are you sure?');">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    `);
                                });

                            } else {
                                $('#showTable tbody').html(
                                    `<tr><td colspan="8" class='text-danger fw-bold'>No results found.</td></tr>`
                                );
                            }

                            $('#showTable').find('thead').show();
                            $('#showTable').find('tbody').show();
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/specialDiet/index.blade.php ENDPATH**/ ?>