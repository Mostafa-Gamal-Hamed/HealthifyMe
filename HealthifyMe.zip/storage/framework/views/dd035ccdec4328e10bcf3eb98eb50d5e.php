<?php $__env->startSection('title'); ?>
    <?php echo e($category->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid mb-5">
        <h2 class="text-center text-success fw-bold mt-3 mb-3"><?php echo e($category->name); ?></h2>

        <div class="shadow shadow-lg bg-light text-dark p-3 mb-5">
            <div class="p-4">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="fw-bold">Category foods:</h4>
                    <h5 class="text-muted">Total: <?php echo e(count($category->foods)); ?></h5>
                </div>
                <div class="row gap-2 justify-content-around mb-3">
                    <?php $__currentLoopData = $category->foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-3">
                            <?php echo e($loop->iteration); ?>- <a href="<?php echo e(route('admin.food.show', $food->id )); ?>" style="margin-right: 5px;"><?php echo e($food->name); ?></a>
                            <span>Date: <?php echo e($food->created_at->format('d/m/Y')); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <p class="text-end text-muted">Created at: <?php echo e($category->created_at->format('d/m/Y')); ?></p>
                <hr>
                <div class="d-flex">
                    <div class="col">
                        <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>" class="btn btn-md btn-success w-75"
                            title="Edit">
                            <i class="fa-solid fa-edit"></i></i>
                        </a>
                    </div>
                    <form action="<?php echo e(route('admin.category.secondDelete', $category->id)); ?>" method="POST" class="col">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-md w-75"
                            onclick="return confirm('Are you sure?');" title="Delete">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/category/show.blade.php ENDPATH**/ ?>