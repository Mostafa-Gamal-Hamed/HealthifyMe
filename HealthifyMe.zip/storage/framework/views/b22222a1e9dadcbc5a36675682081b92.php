<?php $__env->startSection('title'); ?>
    Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="titlepage mt-5">
        <h2>Categories</h2>
    </div>

    <div class="container mb-5">
        <?php if($categories->isEmpty()): ?>
            <h2 class="text-center text-danger fw-bold">Empty</h2>
        <?php else: ?>
            <div class="row shadow bg-light">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4 mb-4">
                        <a href="<?php echo e(route('food.type', $category->name)); ?>">
                            <div class="card position-relative text-center">
                                <div>
                                    <img src="<?php echo e(asset("images/logo.png")); ?>" alt="image"
                                    class="img-fluid object-cover object-center w-50 h-50">
                                </div>
                                <div class="card-body">
                                    <h4 class="card-title fw-bold"><?php echo e($category->name); ?></h4>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/user/food/index.blade.php ENDPATH**/ ?>