<?php $__env->startSection('title'); ?>
    <?php echo e($food->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid mb-5">
        <h2 class="text-center text-success fw-bold mt-3 mb-3"><?php echo e($food->name); ?></h2>

        <div class="shadow shadow-lg bg-light text-dark p-3 mb-5">
            <p class="text-center text-success fw-bold">Items per 100g</p>
            <div class="row justify-content-center">
                <div class="col border-end border-2 text-center">
                    <img src="<?php echo e($food->image ? asset("storage/$food->image") : asset('images/modern_logo.png')); ?>"
                        style="cursor: pointer;" class="img-fluid rounded" alt="Blog">
                </div>
                <div class="col">
                    <h4 class="fw-bold">Calories: <?php echo e($food->calories); ?></h4>
                    <h4 class="fw-bold">Protein: <?php echo e($food->protein); ?></h4>
                    <h4 class="fw-bold">Carbs: <?php echo e($food->carbs); ?></h4>
                    <h4 class="fw-bold">Fats: <?php echo e($food->fats); ?></h4>
                    <h4 class="fw-bold">Vitamins: <?php echo e($food->vitamins); ?></h4>
                    <p class="fw-bold d-flex gap-2">Category:
                        <a href="<?php echo e(route('admin.category.categories')); ?>">
                            <?php echo e($food->category->name); ?>

                        </a>
                    </p>
                    <div class="row gap-2 justify-content-between">
                        <p class="col text-start fw-bold">Created at: <?php echo e($food->created_at->format("d/m/Y")); ?></p>
                        <p class="col text-end fw-bold">Updated at: <?php echo e($food->updated_at->format("d/m/Y")); ?></p>
                    </div>
                    <hr>
                    <div class="d-flex">
                        <div class="col">
                            <a href="<?php echo e(route('admin.food.edit', $food->id)); ?>" class="btn btn-md btn-success w-75" title="Edit">
                                <i class="fa-solid fa-edit"></i></i>
                            </a>
                        </div>
                        <form action="<?php echo e(route('admin.food.secondDelete', $food->id)); ?>" method="POST" class="col">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-md w-75"
                                onclick="return confirm('Are you sure?');" title="Delete">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/food/show.blade.php ENDPATH**/ ?>