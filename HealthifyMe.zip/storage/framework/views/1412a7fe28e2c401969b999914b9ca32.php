<?php $__env->startSection('title'); ?>
    <?php echo e($category->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="titlepage mt-5">
        <h2><?php echo e($category->name); ?></h2>
    </div>

    <div class="container mb-5">
        <?php if($foods->isEmpty()): ?>
            <h2 class="text-center text-danger fw-bold">Empty</h2>
        <?php else: ?>
            <h4 class="text-center fw-bold">Click on one <i class="fa-solid fa-arrow-down"></i></h4>
            <div class="row justify-content-center align-items-center mb-3 gap-2">
                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $rand = $color[array_rand($color)];
                    ?>

                    <button class="col btn btn-sm btn-<?php echo e($rand); ?> showFood" data-id="<?php echo e($food->id); ?>"><?php echo e($food->name); ?></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div style="max-height: 700px;min-height: 500px;width: 100%;">
                
                <div id="logoBeforeFood" class="text-center"><img src="<?php echo e(asset('images/logo.png')); ?>" class="img-fluid" width="50%" alt="Logo"></div>

                
                <div class="row shadow bg-light shadow-lg justify-content-center p-3 gap-2" id="details"
                    style="display: none;">
                    <p class="col-xl-12 text-center text-success fw-bold">Items per 100g</p>
                    <div class="col-xl-5">
                        <div class="about-box_img">
                            <figure>
                                <img src="" class="img-fluid rounded" id="foodImage" alt="Food">
                            </figure>
                        </div>
                    </div>
                    <div class="col-xl-5 position-relative">
                        <div class="about-box">
                            <h1 class="fw-bold" id="foodName">About us</h1>
                            <div class="table-responsive rounded overflow-auto">
                                <table class="table shadow table-light text-center rounded">
                                    <thead class="table-dark">
                                        <tr>
                                            <th scope="col">Calories</th>
                                            <th scope="col">Protein</th>
                                            <th scope="col">Carbs</th>
                                            <th scope="col">Fats</th>
                                            <th scope="col">Vitamins</th>
                                            <th scope="col">Fiber</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="fw-bold">
                                            <td id="Calories"></td>
                                            <td id="Protein"></td>
                                            <td id="Carbs"></td>
                                            <td id="Fats"></td>
                                            <td id="Vitamins"></td>
                                            <td id="Fiber"></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('.showFood').on('click', function() {
                let id = $(this).data('id');

                $.ajax({
                    type: 'GET',
                    url: `<?php echo e(route('food.show', '')); ?>/` + id,
                    success: function(data) {
                        $('#logoBeforeFood').fadeOut();
                        $('#details').hide(50);
                        $('#details').show(250);

                        $('#foodName').text(data.name);
                        $('#foodImage').attr('src', `<?php echo e(asset('storage')); ?>/${data.image}`);
                        $('#Calories').text(data.calories);
                        $('#Protein').text(data.protein);
                        $('#Carbs').text(data.carbs);
                        $('#Fats').text(data.fats);
                        $('#Vitamins').text(data.vitamins);
                        $('#Fiber').text(data.fiber);
                    },
                    error: function(xhr, status, error) {
                        alert("Failed to load food details. Please try again.");
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/user/food/show.blade.php ENDPATH**/ ?>