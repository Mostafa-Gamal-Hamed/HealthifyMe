<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="initial-scale=1, maximum-scale=1">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="HealthifyMe">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- General favicon for all browsers -->
    <link rel="icon" href="<?php echo e(asset('images/favicon.png')); ?>" type="image/x-icon">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>

    
    <script src="<?php echo e(asset('js/jQuery.js')); ?>"></script>
    <?php echo $__env->yieldContent('jquery'); ?>

    
    <script src="<?php echo e(asset('js/sweetAlert.js')); ?>"></script>
</head>

<body>
<?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/user/inc/header.blade.php ENDPATH**/ ?>