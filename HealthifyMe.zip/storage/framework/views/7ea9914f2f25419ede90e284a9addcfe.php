<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    
    <?php echo $__env->make('message', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php if($info != null): ?>
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
                <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg border border-success">
                    
                    <div class="d-flex justify-content-between w-100 mb-3">
                        <p>Name : <?php echo e(ucfirst($user->firstName)); ?> <?php echo e(ucfirst($user->lastName)); ?></p>

                        <p>
                            Account : <span
                                class="<?php echo e($user->status == 'active' ? 'text-success fw-bold' : 'text-danger fw-bold'); ?>">
                                <?php echo e($user->status == 'active' ? 'Activated' : 'Inactive'); ?>

                            </span>
                        </p>

                        <?php if(!$dietInfo): ?>
                            <p class="text-info">Please update your data.</p>
                        <?php elseif($user->status === 'inactive'): ?>
                            <form action="<?php echo e(route('ask-for-diet.store')); ?>" method="post" class="text-end">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-success px-4">Activation request</button>
                            </form>
                        <?php elseif($user->diets->isNotEmpty() || $user->specialDiet): ?>
                            <form action="<?php echo e(route('change-diet.store')); ?>" method="post" class="text-end">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-info px-3">Change diet plane</button>
                            </form>
                        <?php else: ?>
                            <p class="text-muted">Wait for your diet to be created.</p>
                        <?php endif; ?>
                    </div>

                    
                    <div class="calories mb-4">
                        <p class="text-muted text-center">Calculating calories based on activity level</p>
                        <div class="row align-items-center justify-content-between gap-2 equationByActivity">
                            <h5 class="col-md-4" style="width: 48%;">Total daily calories (TDEE): <span class="fw-bold"><?php echo e($tdee); ?></span> Calories</h5>
                            <h5 class="col-md-4 text-end" style="width: 48%;">To lose 0.5 kg per week: <span class="fw-bold"><?php echo e($lose_05kg); ?></span> Calories per day</h5>
                            <h5 class="col-md-4" style="width: 48%;">To lose 1 kg per week: <span class="fw-bold"><?php echo e($lose_1kg); ?></span> Calories per day</h5>
                            <h5 class="col-md-4 text-end" style="width: 48%;">To lose 1.5 kg per week: <span class="fw-bold"><?php echo e($lose_1_5kg); ?></span> Calories per day</h5>
                        </div>
                    </div>

                    
                    <div class="card">
                        <div class="card-body">
                            <div class="owl-carousel owl-theme owl-loaded">
                                <div class="owl-stage-outer">
                                    <div class="owl-stage">
                                        <?php $__currentLoopData = $diets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="owl-item">
                                                <div class="mb-3">
                                                    <h2 class="card-title text-center fw-bold">Diet Plan
                                                        <?php echo e($loop->iteration); ?>

                                                    </h2>
                                                    <div>
                                                        <p class="card-text">Your diet plan is:
                                                            <?php echo e($diet->name ?? 'Not created yet'); ?>

                                                        </p>
                                                        <br>
                                                        <p class="card-text">Your diet plan is:
                                                            <?php echo e($diet->description ?? 'Not created yet'); ?>

                                                        </p>
                                                    </div>
                                                    <h2 class="text-center fw-bold mt-3">Exercises</h2>
                                                    <div class="row justify-content-between align-items-center gap-2">
                                                        <?php $__currentLoopData = json_decode($diet->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="col-md-3">
                                                                <img src="<?php echo e(asset('storage/' . $image ?? 'diets/Diet.jpg')); ?>"
                                                                    data-featherlight="<img src='<?php echo e(asset('storage/' . $image ?? 'diets/Diet.jpg')); ?>' style='max-width:500px;' class='img-fluid'>"
                                                                    class="img-fluid" alt="Diet plan image"
                                                                    style="cursor: pointer;">
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                                <p class="text-end text-muted"><?php echo e($diet->created_at->diffForHumans()); ?>

                                                </p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $specialDiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="owl-item">
                                                <div class="mb-3">
                                                    <h2 class="card-title text-center fw-bold">Diet Plan
                                                        <?php echo e($loop->iteration); ?>

                                                    </h2>
                                                    <div>
                                                        <p class="card-text">Your diet plan is:
                                                            <?php echo e($diet->name ?? 'Not created yet'); ?>

                                                        </p>
                                                        <br>
                                                        <p class="card-text">Your diet plan is:
                                                            <?php echo e($diet->description ?? 'Not created yet'); ?>

                                                        </p>
                                                    </div>
                                                    <h2 class="text-center fw-bold mt-3">Exercises</h2>
                                                    <div class="row justify-content-between align-items-center gap-2">
                                                        <?php $__currentLoopData = json_decode($diet->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="col-md-3">
                                                                <img src="<?php echo e(asset('storage/' . $image ?? 'diets/Diet.jpg')); ?>"
                                                                    data-featherlight="<img src='<?php echo e(asset('storage/' . $image ?? 'diets/Diet.jpg')); ?>' style='max-width:500px;' class='img-fluid'>"
                                                                    class="img-fluid" alt="Diet plan image"
                                                                    style="cursor: pointer;">
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                                <p class="text-end text-muted"><?php echo e($diet->created_at->diffForHumans()); ?>

                                                </p>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php endif; ?>

    
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg border border-info">
                <h1 class="text-center fw-bold fs-4 mb-4">Your last data</h1>

                <div class="row justify-content-between w-100 gap-2 mb-4">
                    <div class="col-2 rounded form-control" style="width: 48%;">
                        Gender : <span class="fw-bold"><?php echo e($dietInfo ? $dietInfo->gender : '0'); ?></span>
                    </div>
                    <div class="col-2 rounded form-control" style="width: 48%;">
                        Age : <span class="fw-bold"><?php echo e($dietInfo ? $dietInfo->age : '0'); ?></span> years
                    </div>
                    <div class="col-2 rounded form-control" style="width: 48%;">
                        Weight : <span class="fw-bold"><?php echo e($dietInfo ? $dietInfo->weight : '0'); ?></span> Kg
                    </div>
                    <div class="col-2 rounded form-control" style="width: 48%;">
                        Height : <span class="fw-bold"><?php echo e($dietInfo ? $dietInfo->height : '0'); ?></span> cm
                    </div>
                    <div class="col-2 rounded form-control" style="width: 48%;">
                        Activity level : <span class="fw-bold"><?php echo e($dietInfo ? ucfirst($dietInfo->activity_level) : '0'); ?></span>
                    </div>
                    <div class="col-2 rounded form-control" style="width: 48%">
                        Workout hours per week : <span
                            class="fw-bold"><?php echo e($dietInfo ? $dietInfo->workout_hours_per_week : '0'); ?></span> hour
                    </div>
                </div>


                <div class="text-center">
                    <a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-primary px-4">Update data</a>
                </div>
            </div>
        </div>
    </div>

    
    <script>
        $(document).ready(function() {
            $(".owl-carousel").owlCarousel({
                items: 1,
                loop: true,
                margin: 10,
                nav: false,
                responsive: {
                    0: {
                        items: 1,
                        nav: false
                    },
                    600: {
                        items: 1,
                        nav: false
                    },
                    1000: {
                        items: 1,
                        nav: false,
                        loop: true
                    }
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/dashboard.blade.php ENDPATH**/ ?>