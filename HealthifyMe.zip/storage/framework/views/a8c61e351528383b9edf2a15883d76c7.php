<?php $__env->startSection('title'); ?>
    Recipes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="p-3">
        <h2 class="text-center mb-3 text-success fw-bold">All recipes</h2>

        
        <?php echo $__env->make('admin.success', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="shadow shadow-lg bg-light rounded h-100 mb-5">
            <?php if($recipes->isEmpty()): ?>
                <h3 class="mb-5 text-center text-danger">No recipes found.</h3>
            <?php else: ?>
                
                <form class="d-flex justify-content-end mb-3 p-2" role="search">
                    <input class="form-control w-50" type="text" id="search" placeholder="Search by title"
                        aria-label="Search">
                </form>

                
                <div class="table-responsive">
                    <?php echo e($recipes->appends(request()->input())->links()); ?>

                    <table class="table text-center" id="showTable">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Title</th>
                                <th scope="col">Description</th>
                                <th scope="col">Calories</th>
                                <th scope="col">Status</th>
                                <th scope="col">Created</th>
                                <th scope="col" colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($recipe->id); ?></td>
                                    <td><?php echo e($recipe->title); ?></td>
                                    <td>
                                        <span class="text" data-featherlight="<p><?php echo e($recipe->description); ?></p>"
                                            style="cursor: pointer;">
                                            <?php echo Str::limit($recipe->description, 250, '....'); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($recipe->calories); ?></td>
                                    <td><?php echo e($recipe->status); ?></td>
                                    <td><?php echo e($recipe->created_at->format('d-m-Y')); ?></td>
                                    <td>
                                        <?php if (isset($component)) { $__componentOriginalc77d73ad08c25a406445baf856031498 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc77d73ad08c25a406445baf856031498 = $attributes; } ?>
<?php $component = App\View\Components\EditShow::resolve(['url' => ''.e(route('admin.recipe.show', $recipe->id)).'','class' => 'info','title' => 'Details','text' => '<i class=\'fa-solid fa-info\'></i>'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('EditShow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\EditShow::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc77d73ad08c25a406445baf856031498)): ?>
<?php $attributes = $__attributesOriginalc77d73ad08c25a406445baf856031498; ?>
<?php unset($__attributesOriginalc77d73ad08c25a406445baf856031498); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc77d73ad08c25a406445baf856031498)): ?>
<?php $component = $__componentOriginalc77d73ad08c25a406445baf856031498; ?>
<?php unset($__componentOriginalc77d73ad08c25a406445baf856031498); ?>
<?php endif; ?>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.recipe.delete', $recipe->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-md"
                                                onclick="return confirm('Are you sure?');">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php if($recipes->isNotEmpty()): ?>
        <script>
            $(document).ready(function() {
                $("#search").on("input", function() {
                    var value = $(this).val().toLowerCase();
                    $('#showTable').find('thead').hide();
                    $('#showTable').find('tbody').hide();

                    if (value === ' ') {
                        $('#showTable').find('thead').show();
                        $('#showTable').find('tbody').show();
                    }

                    $.ajax({
                        type: "GET",
                        url: "<?php echo e(route('admin.recipe.search', '')); ?>/" + value,
                        success: function(response) {
                            console.log(response.recipes);
                            var resultHtml = '';

                            if (response.recipes && response.recipes.length > 0) {
                                var body = $('#showTable').find('tbody');
                                body.empty();

                                response.recipes.forEach(function(recipe) {
                                    var created_at = new Date(recipe.created_at);
                                    var createdAt = created_at.toLocaleDateString('en-GB');

                                    var data = `data-featherlight='<p>${recipe.description}</p>'`;
                                    var description = `
                                        <span class="text" ${data} style="cursor: pointer;">
                                            ${recipe.description.length > 50 ? recipe.description.substring(0, 50) + '....' : recipe.description}
                                        </span>
                                    `;

                                    var status = recipe.status || " ";

                                    var show =
                                        `<?php echo e(route('admin.recipe.show', '')); ?>/${recipe.id}`;
                                    var remove =
                                        `<?php echo e(route('admin.recipe.delete', '')); ?>/${recipe.id}`;

                                    body.append(`
                                        <tr>
                                            <td scope="row">${recipe.id}</td>
                                            <td>${recipe.title}</td>
                                            <td>${description}</td>
                                            <td>${recipe.calories}</td>
                                            <td>${status}</td>
                                            <td>${createdAt}</td>
                                            <td>
                                                <?php if (isset($component)) { $__componentOriginalc77d73ad08c25a406445baf856031498 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc77d73ad08c25a406445baf856031498 = $attributes; } ?>
<?php $component = App\View\Components\EditShow::resolve(['url' => '${show}','class' => 'info','title' => 'Details','text' => '<i class=\'fa-solid fa-info\'></i>'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('EditShow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\EditShow::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc77d73ad08c25a406445baf856031498)): ?>
<?php $attributes = $__attributesOriginalc77d73ad08c25a406445baf856031498; ?>
<?php unset($__attributesOriginalc77d73ad08c25a406445baf856031498); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc77d73ad08c25a406445baf856031498)): ?>
<?php $component = $__componentOriginalc77d73ad08c25a406445baf856031498; ?>
<?php unset($__componentOriginalc77d73ad08c25a406445baf856031498); ?>
<?php endif; ?>
                                            </td>
                                            <td>
                                                <form action="${remove}" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-md"
                                                        onclick="return confirm('Are you sure?');">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    `);
                                });

                            } else {
                                $('#showTable tbody').html(
                                    `<tr><td colspan="8" class='text-danger fw-bold'>No results found.</td></tr>`
                                );
                            }

                            $('#showTable').find('thead').show();
                            $('#showTable').find('tbody').show();
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/recipe/index.blade.php ENDPATH**/ ?>