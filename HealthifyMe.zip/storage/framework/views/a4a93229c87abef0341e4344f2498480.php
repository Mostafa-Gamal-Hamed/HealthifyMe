
<?php if($errors->any()): ?>
    <script>
        let errorMessages = <?php echo json_encode($errors->all(), 15, 512) ?>;
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            html: errorMessages.map(error => `<p>${error}</p>`).join(''),
        });
    </script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/error.blade.php ENDPATH**/ ?>