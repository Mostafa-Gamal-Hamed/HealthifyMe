<a href="<?php echo e($url); ?>" class="btn btn-md btn-<?php echo e($class); ?>" title="<?php echo e($title); ?>">
    <?php echo $text; ?>

</a><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/components/edit-show.blade.php ENDPATH**/ ?>