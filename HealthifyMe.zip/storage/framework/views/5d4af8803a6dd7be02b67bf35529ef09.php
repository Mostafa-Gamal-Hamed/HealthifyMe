<?php $__env->startSection('title'); ?>
    Blogs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="titlepage mt-5">
        <h2>Blogs</h2>
    </div>

    <div class="container mb-5">
        <div class="row align-items-center gap-3 justify-content-around" id="blogsContainer">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card col-3" style="width: 18rem;">
                    <img src="<?php echo e($blog->image ? asset("images/$blog->image") : asset('images/home_food.png')); ?>"
                        class="card-img-top" alt="Blog">
                    <div class="card-body">
                        <h5 class="card-title text-center"><strong><?php echo e($blog->title); ?></strong></h5>
                        <p class="text-end text-muted p-0"><?php echo e($blog->created_at); ?></p>
                        <p class="card-text mb-2"><?php echo Str::limit($blog->desc, 100); ?></p>
                        <a href="<?php echo e(route('blog.show', $blog->id)); ?>" class="btn btn-outline-success px-5">Read</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div id="showMoreBlogs"></div>
        <div class="w-100 mt-3 text-center">
            <button type="button" class="btn btn-primary px-5" id="moreBlogs">More</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            var offset = <?php echo e(count($blogs)); ?>;
            var limit = 9;

            $('#moreBlogs').click(function() {
                $.ajax({
                    url: "<?php echo e(route('blog.blogs')); ?>",
                    type: 'GET',
                    data: {
                        offset: offset,
                        limit: limit
                    },
                    success: function(response) {
                        if (response.blogs.length > 0) {
                            var blogsHtml = '';
                            $.each(response.blogs, function(index, blog) {
                                blogsHtml += `
                                <div class="card col-3" style="width: 18rem;">
                                    ${offset + index + 1}
                                    <img src="${blog.image ? '<?php echo e(asset('images')); ?>/' + blog.image : '<?php echo e(asset('images/home_food.png')); ?>'}"
                                        class="card-img-top" alt="Blog">
                                    <div class="card-body">
                                        <h5 class="card-title text-center"><strong>${blog.title}</strong></h5>
                                        <p class="text-end text-muted p-0">${blog.created_at}</p>
                                        <p class="card-text mb-2">${blog.desc.substring(0, 100)}...</p>
                                        <a href="<?php echo e(route('blog.show', '')); ?>/${blog.id}" class="btn btn-outline-success px-5">Read</a>
                                    </div>
                                </div>
                            `;
                            });

                            $('#blogsContainer').append(blogsHtml);
                            offset += limit;

                            if (!response.hasMore) {
                                $('#moreBlogs').hide();
                            }
                        } else {
                            $('#moreBlogs').hide();
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/user/pages/blog.blade.php ENDPATH**/ ?>