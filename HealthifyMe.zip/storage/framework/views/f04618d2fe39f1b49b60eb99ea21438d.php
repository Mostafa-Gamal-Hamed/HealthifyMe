<?php $__env->startSection('body'); ?>
    
    <div class="mt-5 mb-5 p-4">
        <div class="titlepage">
            <h2> <strong class="llow">Testi</strong>monial </h2>
        </div>

        <div class="owl-carousel owl-theme owl-loaded">
            <div class="owl-stage-outer">
                <div class="owl-stage">
                    <div class="owl-item d-flex flex-column align-items-center">
                        <figure class="col">
                            <img src="<?php echo e(asset('images/tes.jpg')); ?>" class="w-50 m-auto rounded-circle" alt="Testimonial">
                        </figure>
                        <div class="col text-center">
                            <h3>Mostafa hamed</h3>
                            <p>It is a long established fact that a reader will be distracted by the
                                readable content of a page when looking at its layout. The point of
                                using
                                Lorem Ipsum is that it has a more-or-less normal distribution of
                                letters, as
                                opposed to using 'Content here, content here', making it look like
                                readable
                                English. Many desktop publishing packages and
                            </p>
                        </div>
                    </div>
                    <div class="owl-item d-flex flex-column align-items-center">
                        <figure class="col">
                            <img src="<?php echo e(asset('images/tes.jpg')); ?>" class="w-50 m-auto rounded-circle" alt="Testimonial">
                        </figure>
                        <div class="col text-center">
                            <h3>Ahmed Ibrahim</h3>
                            <p>It is a long established fact that a reader will be distracted by the
                                readable content of a page when looking at its layout. The point of
                                using
                                Lorem Ipsum is that it has a more-or-less normal distribution of
                                letters, as
                                opposed to using 'Content here, content here', making it look like
                                readable
                                English. Many desktop publishing packages and
                            </p>
                        </div>
                    </div>
                    <div class="owl-item d-flex flex-column align-items-center">
                        <figure class="col">
                            <img src="<?php echo e(asset('images/tes.jpg')); ?>" class="w-50 m-auto rounded-circle" alt="Testimonial">
                        </figure>
                        <div class="col text-center">
                            <h3>Mona mahmoud</h3>
                            <p>It is a long established fact that a reader will be distracted by the
                                readable content of a page when looking at its layout. The point of
                                using
                                Lorem Ipsum is that it has a more-or-less normal distribution of
                                letters, as
                                opposed to using 'Content here, content here', making it look like
                                readable
                                English. Many desktop publishing packages and
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/user/pages/testimonial.blade.php ENDPATH**/ ?>