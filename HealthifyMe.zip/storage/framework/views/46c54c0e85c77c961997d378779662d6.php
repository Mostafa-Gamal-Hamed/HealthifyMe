<?php $__env->startSection('title'); ?>
    Diet Requests
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="p-3">
        <div class="shadow shadow-lg bg-light rounded h-100 p-4">
            <?php if($dietRequests->isEmpty()): ?>
                <h3 class="mb-5 text-center text-danger">No Requests found.</h3>
            <?php else: ?>
                <div class="row justify-content-between align-items-center mb-4">
                    <h6 class="col">Requests</h6>
                    <form class="col" role="search">
                        <input class="form-control me-2" type="text" id="search" placeholder="Search Request"
                            aria-label="Search">
                    </form>
                </div>
                <div class="table-responsive">
                    <?php echo e($dietRequests->appends(request()->input())->links()); ?>

                    <table class="table text-center" id="showTable">
                        <thead>
                            <tr>
                                <th>ID.</th>
                                <th>Request</th>
                                <th>User name</th>
                                <th>Approved</th>
                                <th>Date</th>
                                <th colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dietRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($request->id); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($request->ask === 'ask' ? 'primary' : 'warning text-dark'); ?>">
                                            <?php echo e($request->ask); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($request->user->firstName); ?></td>
                                    <td><?php echo e($request->accept == 0 ? 'no' : 'yes'); ?></td>
                                    <td><?php echo e($request->created_at->format('d-m-Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.user.show', $request->user->id)); ?>" class="btn btn-md btn-success">
                                            <i class="fa-solid fa-info"></i></i>
                                        </a>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.dietRequests.delete', $request->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-md"
                                                onclick="return confirm('Are you sure?');">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $("#search").on("input", function() {
                var value = $(this).val().toLowerCase();
                $('#showTable').find('thead').hide();
                $('#showTable').find('tbody').hide();

                if (value === '') {
                    $('#showTable').find('thead').show();
                    $('#showTable').find('tbody').show();
                    return;
                }

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(route('admin.dietRequests.search', '')); ?>/" + value,
                    success: function(response) {
                        var resultHtml = '';

                        if (response.requests && response.requests.length > 0) {
                            var body = $('#showTable').find('tbody');
                            body.empty();

                            response.requests.forEach(function(request) {
                                var created_at = new Date(request.created_at);
                                var createdAt = created_at.toLocaleDateString('en-GB');

                                var askClass = request.ask === 'ask' ? 'primary' : 'warning text-dark';
                                var askLabel = `<span class="badge bg-${askClass}">${request.ask}</span>`;

                                var approved = request.accept == 0 ? 'no' : 'yes';

                                var show   = `<?php echo e(route('admin.user.show', '')); ?>/${request.id}`;
                                var remove = `<?php echo e(route('admin.dietRequests.delete', '')); ?>/${request.id}`;

                                body.append(`
                                    <tr>
                                        <td scope="row">${request.id}</td>
                                        <td>${askLabel}</td>
                                        <td>${request.user.firstName}</td>
                                        <td>${approved}</td>
                                        <td>${createdAt}</td>
                                        <td>
                                            <a href="${show}" class="btn btn-md btn-success">
                                                <i class="fa-solid fa-info"></i></i>
                                            </a>
                                        </td>
                                        <td>
                                            <form action="${remove}" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-md"
                                                    onclick="return confirm('Are you sure?');">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                `);
                            });

                        } else {
                            $('#showTable tbody').html(
                                `<tr><td colspan="8" class='text-danger fw-bold'>No results found.</td></tr>`
                            );
                        }

                        $('#showTable').find('thead').show();
                        $('#showTable').find('tbody').show();
                    },
                    error: function(xhr, status, error) {
                        console.error('Error:', error);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/user/dietRequest/index.blade.php ENDPATH**/ ?>