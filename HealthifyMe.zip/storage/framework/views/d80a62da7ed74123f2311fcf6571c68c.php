<?php $__env->startSection('title'); ?>
    <?php echo e($message->subject); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid mb-5">
        <h2 class="text-center text-success fw-bold mt-3 mb-3"><?php echo e($message->email); ?></h2>

        
        <?php echo $__env->make("message", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="shadow shadow-xl text-dark p-3 mb-5" style="background-color: #eeeeee;">
            <div class="text-center overflow-auto">
                
                <div class="mb-3">
                    <p>Name</p>
                    <h4 class="w-50 m-auto p-2 rounded" style="background-color: white;"><?php echo e($message->name); ?></h4>
                </div>
                
                <div class="mb-3">
                    <p>Email</p>
                    <h4 class="w-auto m-auto p-2 rounded" style="background-color: white;"><?php echo e($message->email); ?></h4>
                </div>
                
                <div class="mb-3">
                    <p>Subject</p>
                    <h4 class="w-50 m-auto p-2 rounded" style="background-color: white;"><?php echo e($message->subject); ?></h4>
                </div>
                
                <div class="mb-3">
                    <p>Message</p>
                    <h4 class="p-2 rounded" style="background-color:white;"><?php echo e($message->message); ?></h4>
                </div>
            </div>
            <hr>
            <div class="d-flex">
                <div class="col">
                    <a href="#" class="btn btn-md btn-success w-75" id="reply" title="Replay message">
                        <i class="fa-solid fa-reply"></i>
                    </a>
                </div>
                <form action="<?php echo e(route('admin.contact.secondDelete', $message->id)); ?>" method="POST" class="col">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-md w-75" onclick="return confirm('Are you sure?');"
                        title="Delete message">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </form>
            </div>
        </div>
        <hr>

        
        <div class="shadow shadow-xl text-dark p-3 mb-5 text-center" id="sentMessage" style="background-color: #eeeeee; display: none;">
            <h2 class="mb-3">Sent message</h2>
            <form action="<?php echo e(route('admin.sentMessage.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                
                <div class="input-group mb-3">
                    <span class="input-group-text" id="email">To</span>
                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email"
                    value="<?php echo e($message->email); ?>" aria-describedby="email">
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <div class="input-group mb-3">
                    <span class="input-group-text">Message</span>
                    <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="message" name="message" aria-label="message"></textarea>
                </div>
                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <button type="submit" class="btn btn-primary px-5">Send</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            // Sent message
            $('#reply').click(function (e) {
                e.preventDefault();
                $('#sentMessage').toggle(500);
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/admin/contact/show.blade.php ENDPATH**/ ?>