
<?php if(session()->get('success')): ?>
<script>
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: '<?php echo e(session('success')); ?>',
        });
    </script>
<?php endif; ?>


<?php if($errors->any()): ?>
    <script>
        let errorMessages = <?php echo json_encode($errors->all(), 15, 512) ?>;
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            html: errorMessages.map(error => `<p>${error}</p>`).join(''),
        });
    </script>
<?php endif; ?>


<?php if(session()->get('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: `<?php echo e(session()->get('error')); ?>`,
        });
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\HealthifyMe\resources\views/message.blade.php ENDPATH**/ ?>